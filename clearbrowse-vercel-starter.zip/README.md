# ClearBrowse — low-ad browsing dashboard

A clean, light Next.js starter hosted on Vercel. Includes:
- Address/search form that opens sites in a new tab.
- Clean Reader endpoint using Mozilla Readability and sanitized HTML.
- Left sidebar with 15 recent headlines aggregated from BBC World, The Guardian, and NPR RSS feeds; refreshes every five minutes.
- To-do list UI.
- Responsive desktop/mobile layout.

## Important product limitation

This is a **web app**, not a full browser. Normal websites can prevent embedding, and a Vercel app cannot intercept network requests made by other tabs or apps. It therefore cannot guarantee that ads are blocked on arbitrary websites or YouTube. For stronger network-level ad blocking, build a Chrome/Firefox extension as a companion product. Do not market this starter as a guaranteed ad-free YouTube player.

## Run locally

Requires Node.js 20.9+.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

Check production compilation:

```bash
npm run build
```

## Deploy to Vercel

1. Create a new GitHub repository and upload these files.
2. Push the repository to GitHub.
3. In Vercel, choose **Add New → Project**, import the repository, and keep the detected Next.js settings.
4. Click **Deploy**. No environment variables are required for this starter.
5. After deployment, test the homepage, `/api/news`, and Clean Reader with a public article URL.

You can also use the Vercel CLI:

```bash
npm install
npm run build
npx vercel
npx vercel --prod
```

## Project structure

```text
app/
  api/
    news/route.ts       # RSS aggregation endpoint
    reader/route.ts     # Article extraction endpoint
  globals.css           # Light responsive design
  layout.tsx
  page.tsx               # Browser dashboard, news, and tasks
package.json
next.config.ts
tsconfig.json
```

## Current limitations and next steps

- To-do tasks persist in the browser's localStorage on that device. They are not synced across devices.
- News is best-effort RSS aggregation. Feeds can be unavailable or rate-limited; the app displays available stories and refreshes every five minutes.
- The reader API includes URL/IP checks and redirect validation, but public URL-fetching endpoints are security-sensitive. Before production launch, add rate limiting, strict egress controls, monitoring, and review the SSRF protections for your hosting environment.
- The reader may fail for login-gated, JavaScript-rendered, paywalled, or anti-bot-protected pages.
- YouTube is a shortcut to the official site; embedded playback may still show ads.
