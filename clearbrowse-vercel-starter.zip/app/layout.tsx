import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ClearBrowse — a calmer web",
  description: "A clean browsing dashboard with reader mode, live headlines, and a simple task list."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
