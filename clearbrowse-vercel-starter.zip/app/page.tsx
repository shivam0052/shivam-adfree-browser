 "use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";

type NewsItem = { title: string; link: string; source: string; date?: string };
type ReaderResult = { title: string; byline?: string | null; excerpt?: string | null; content: string; textContent?: string | null };

function normalizeUrl(raw: string) {
  const value = raw.trim();
  if (!value) return "";
  const hasScheme = /^[a-zA-Z][a-zA-Z\d+.-]*:/.test(value);
  if (!hasScheme && (/[\\s]/.test(value) || (!value.includes(".") && !value.includes("/") && !value.startsWith("localhost")))) {
    return `https://www.google.com/search?q=${encodeURIComponent(value)}`;
  }
  const candidate = hasScheme ? value : `https://${value}`;
  try {
    const url = new URL(candidate);
    if (!["http:", "https:"].includes(url.protocol)) return "";
    return url.toString();
  } catch {
    return `https://www.google.com/search?q=${encodeURIComponent(value)}`;
  }
}

function timeLabel(date?: string) {
  if (!date) return "Latest";
  const parsed = new Date(date);
  if (Number.isNaN(parsed.getTime())) return "Latest";
  return parsed.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function Home() {
  const [address, setAddress] = useState("");
  const [news, setNews] = useState<NewsItem[]>([]);
  const [newsState, setNewsState] = useState("Loading headlines…");
  const [tasks, setTasks] = useState<string[]>([]);
  const [tasksReady, setTasksReady] = useState(false);
  const [taskText, setTaskText] = useState("");
  const [done, setDone] = useState<number[]>([]);
  const [reader, setReader] = useState<ReaderResult | null>(null);
  const [readerError, setReaderError] = useState("");
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<"home" | "reader">("home");

  const refreshNews = useCallback(async () => {
    try {
      const response = await fetch("/api/news", { cache: "no-store" });
      if (!response.ok) throw new Error("News feed unavailable");
      const data = await response.json();
      setNews(Array.isArray(data.items) ? data.items.slice(0, 15) : []);
      setNewsState(data.items?.length ? `Updated ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "No headlines returned");
    } catch {
      setNewsState("Could not refresh headlines. Try again shortly.");
    }
  }, []);

  useEffect(() => {
    void refreshNews();
    const timer = window.setInterval(() => void refreshNews(), 5 * 60 * 1000);
    return () => window.clearInterval(timer);
  }, [refreshNews]);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("clearbrowse.tasks");
      if (saved) {
        const parsed: unknown = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.every(item => typeof item === "string")) setTasks(parsed.slice(0, 100));
      }
    } catch {
      // Ignore invalid or unavailable local storage.
    } finally {
      setTasksReady(true);
    }
  }, []);

  useEffect(() => {
    if (!tasksReady) return;
    try {
      window.localStorage.setItem("clearbrowse.tasks", JSON.stringify(tasks));
    } catch {
      // The list still works for this session if storage is unavailable.
    }
  }, [tasks, tasksReady]);

  const openDirect = (event: FormEvent) => {
    event.preventDefault();
    const target = normalizeUrl(address);
    if (!target) return;
    window.open(target, "_blank", "noopener,noreferrer");
  };

  const openReader = async (event: FormEvent) => {
    event.preventDefault();
    const target = normalizeUrl(address);
    if (!target) return;
    setBusy(true);
    setReaderError("");
    setReader(null);
    setMode("reader");
    try {
      const response = await fetch("/api/reader", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: target })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not create reader view.");
      setReader(data);
    } catch (error) {
      setReaderError(error instanceof Error ? error.message : "Could not create reader view.");
    } finally {
      setBusy(false);
    }
  };

  const addTask = (event: FormEvent) => {
    event.preventDefault();
    const next = taskText.trim();
    if (!next) return;
    setTasks(current => [...current, next]);
    setTaskText("");
  };

  const completedCount = useMemo(() => done.length, [done]);

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">C</div>
          <div><strong>ClearBrowse</strong><span>Less clutter. More focus.</span></div>
        </div>

        <section className="side-section news-section">
          <div className="section-heading">
            <div><span className="live-dot" /><h2>Live news</h2></div>
            <button className="icon-button" onClick={() => void refreshNews()} aria-label="Refresh news" title="Refresh news">↻</button>
          </div>
          <p className="muted tiny">{newsState} · 15 headlines</p>
          <ol className="news-list">
            {news.slice(0, 15).map((item, index) => (
              <li key={`${item.link}-${index}`}>
                <a href={item.link} target="_blank" rel="noreferrer">
                  <span className="news-number">{String(index + 1).padStart(2, "0")}</span>
                  <span className="news-copy"><strong>{item.title}</strong><small>{item.source} <span>·</span> {timeLabel(item.date)}</small></span>
                  <span className="external-arrow">↗</span>
                </a>
              </li>
            ))}
            {news.length === 0 && <li className="empty-news">Headlines will appear here when the feeds load.</li>}
          </ol>
          <p className="news-footnote">Headlines link to their publishers. Feed availability may vary.</p>
        </section>

        <section className="side-section todo-section">
          <div className="section-heading">
            <div><span className="todo-icon">✓</span><h2>To-do list</h2></div>
            <span className="task-count">{completedCount}/{tasks.length}</span>
          </div>
          <form className="task-form" onSubmit={addTask}>
            <input value={taskText} onChange={e => setTaskText(e.target.value)} placeholder="Add a task…" aria-label="New task" maxLength={180} />
            <button type="submit" aria-label="Add task">+</button>
          </form>
          <ul className="task-list">
            {tasks.map((task, index) => (
              <li key={`${task}-${index}`} className={done.includes(index) ? "task-done" : ""}>
                <label><input type="checkbox" checked={done.includes(index)} onChange={e => setDone(current => e.target.checked ? [...current, index] : current.filter(n => n !== index))} /><span>{task}</span></label>
                <button className="task-remove" onClick={() => { setTasks(current => current.filter((_, i) => i !== index)); setDone(current => current.filter(n => n !== index).map(n => n > index ? n - 1 : n)); }} aria-label={`Delete ${task}`}>×</button>
              </li>
            ))}
          </ul>
          {tasks.length === 0 && <p className="muted tiny todo-empty">Your tasks will appear here.</p>}
          <p className="local-note">Tasks stay in this page session for now.</p>
        </section>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div className="breadcrumb"><span className="status-pill"><span /> PRIVATE WORKSPACE</span><span className="breadcrumb-divider">/</span><span>{mode === "reader" ? "Reader mode" : "Home"}</span></div>
          <a className="github-link" href="https://vercel.com/new" target="_blank" rel="noreferrer">Deploy on Vercel <span>↗</span></a>
        </header>

        <div className="main-content">
          <div className="hero">
            <div className="eyebrow"><span className="sparkle">✳</span> YOUR CALMER CORNER OF THE WEB</div>
            <h1>Browse with<br /><em>less noise.</em></h1>
            <p className="hero-copy">Search the web, open sites directly, or turn supported articles into a clean reading experience.</p>
          </div>

          <div className="browser-card">
            <div className="browser-card-top"><div className="window-dots"><i /><i /><i /></div><span>QUICK ACCESS</span><span className="secure-label">⌁ HTTPS ready</span></div>
            <form className="address-form" onSubmit={openDirect}>
              <span className="search-icon">⌕</span>
              <input value={address} onChange={e => setAddress(e.target.value)} placeholder="Search Google or enter a website address…" aria-label="Search or enter website address" />
              <button type="submit">Open site <span>↗</span></button>
            </form>
            <div className="browser-actions">
              <button className="reader-button" onClick={(e) => { const form = e.currentTarget.closest(".browser-card")?.querySelector("form"); if (form) form.requestSubmit(); }} type="button" hidden />
              <button onClick={() => { const target = normalizeUrl(address); if (target) window.open(`https://www.google.com/search?q=${encodeURIComponent(address)}`, "_blank", "noopener,noreferrer"); else window.open("https://www.google.com", "_blank", "noopener,noreferrer"); }} className="secondary-button"><span>⌕</span> Search web</button>
              <button onClick={(e) => { e.preventDefault(); const target = normalizeUrl(address); if (!target) { setReaderError("Enter a website URL first."); setMode("reader"); return; } void (async () => { setMode("reader"); setReader(null); setReaderError(""); setBusy(true); try { const response = await fetch("/api/reader", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url: target }) }); const data = await response.json(); if (!response.ok) throw new Error(data.error || "Could not create reader view."); setReader(data); } catch (err) { setReaderError(err instanceof Error ? err.message : "Reader failed."); } finally { setBusy(false); } })(); }} className="secondary-button"><span>☷</span> Clean Reader</button>
              <button onClick={() => window.open("https://www.youtube.com", "_blank", "noopener,noreferrer")} className="secondary-button youtube-button"><span>▶</span> YouTube</button>
            </div>
          </div>

          {mode === "reader" && (
            <section className="reader-panel">
              <div className="reader-panel-head"><div><span className="reader-kicker">CLEAN READER</span><h2>{reader?.title || (busy ? "Preparing your article…" : "Reader view")}</h2></div><button className="close-reader" onClick={() => { setMode("home"); setReader(null); setReaderError(""); }}>Close ×</button></div>
              {busy && <div className="reader-loading"><span className="loader" /> Extracting readable content…</div>}
              {readerError && <div className="error-message">{readerError}<p>Some websites block automated reading or require sign-in. Try opening the site directly instead.</p></div>}
              {reader && <><p className="reader-byline">{reader.byline || reader.excerpt || "Simplified article content"}</p><article className="reader-content" dangerouslySetInnerHTML={{ __html: reader.content }} /></>}
            </section>
          )}

          <section className="feature-grid">
            <article className="feature-card">
              <div className="feature-icon lavender">⌁</div><span className="feature-label">01 / DIRECT BROWSING</span><h3>Open the web as it is</h3><p>Open websites in a separate tab. Sites that block embedding can still be visited normally.</p><span className="feature-status"><i /> Standard web access</span>
            </article>
            <article className="feature-card">
              <div className="feature-icon mint">☷</div><span className="feature-label">02 / CLEAN READER</span><h3>Keep the content</h3><p>Extract article text from supported public pages, with scripts and many page distractions removed.</p><span className="feature-status"><i /> Article extraction</span>
            </article>
            <article className="feature-card">
              <div className="feature-icon peach">▶</div><span className="feature-label">03 / VIDEO</span><h3>Your video shortcut</h3><p>Jump to YouTube quickly. Ad-free playback is not guaranteed in a normal web app.</p><span className="feature-status"><i /> YouTube shortcut</span>
            </article>
          </section>

          <div className="honesty-note"><span>ⓘ</span><p><strong>A note about ads</strong> — This Vercel web app does not intercept all network requests, so it cannot block every ad across arbitrary websites or guarantee ad-free YouTube playback. A browser extension is the next step for stronger blocking.</p></div>
          <footer><span>ClearBrowse <span className="footer-dot">·</span> Built for focus</span><span>News refreshes every 5 minutes <span className="footer-dot">·</span> Links open at their source</span></footer>
        </div>
      </section>
    </main>
  );
}
