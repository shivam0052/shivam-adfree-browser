import { NextRequest, NextResponse } from "next/server";
import { lookup } from "node:dns/promises";
import { isIP } from "node:net";
import { Readability } from "@mozilla/readability";
import { JSDOM } from "jsdom";
import sanitizeHtml from "sanitize-html";

export const runtime = "nodejs";
export const maxDuration = 15;

function isPrivateIPv4(ip: string) {
  const p = ip.split(".").map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return true;
  return p[0] === 0 || p[0] === 10 || p[0] === 127 ||
    (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) || (p[0] === 100 && p[1] >= 64 && p[1] <= 127) ||
    p[0] >= 224;
}
function isPrivateIPv6(ip: string) {
  const value = ip.toLowerCase();
  return value === "::" || value === "::1" || value.startsWith("fc") ||
    value.startsWith("fd") || /^fe[89ab]/.test(value) || value.startsWith("::ffff:127.") ||
    value.startsWith("::ffff:10.") || value.startsWith("::ffff:192.168.");
}
async function validatePublicUrl(raw: string) {
  const url = new URL(raw);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Only HTTP and HTTPS URLs are supported.");
  if (url.username || url.password) throw new Error("URLs with embedded credentials are not allowed.");
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal")) {
    throw new Error("Private and local addresses are not allowed.");
  }
  const ipType = isIP(host);
  if (ipType === 4 && isPrivateIPv4(host)) throw new Error("Private network addresses are not allowed.");
  if (ipType === 6 && isPrivateIPv6(host)) throw new Error("Private network addresses are not allowed.");
  if (!ipType) {
    const records = await lookup(host, { all: true, verbatim: true });
    if (!records.length || records.some(r => isIP(r.address) === 4 ? isPrivateIPv4(r.address) : isPrivateIPv6(r.address))) {
      throw new Error("This host does not resolve to a public address.");
    }
  }
  return url;
}

async function safeFetch(raw: string) {
  let current = raw;
  for (let hop = 0; hop <= 3; hop++) {
    const url = await validatePublicUrl(current);
    const response = await fetch(url, {
      redirect: "manual",
      signal: AbortSignal.timeout(9000),
      headers: { "User-Agent": "Mozilla/5.0 (compatible; ClearBrowseReader/1.0)", "Accept": "text/html,application/xhtml+xml" }
    });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("location");
      if (!location || hop === 3) throw new Error("Too many redirects or invalid redirect.");
      current = new URL(location, url).toString();
      continue;
    }
    if (!response.ok) throw new Error(`The website returned HTTP ${response.status}.`);
    const type = response.headers.get("content-type") || "";
    if (!type.includes("text/html") && !type.includes("application/xhtml+xml")) throw new Error("This URL does not return an HTML page.");
    const declaredLength = Number(response.headers.get("content-length") || 0);
    if (declaredLength > 2_000_000) throw new Error("This page is too large to process.");
    const html = await response.text();
    if (html.length > 2_000_000) throw new Error("This page is too large to process.");
    return { html, url: url.toString() };
  }
  throw new Error("Could not safely load this page.");
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    if (typeof body.url !== "string" || body.url.length > 2048) {
      return NextResponse.json({ error: "Please provide a valid URL under 2,048 characters." }, { status: 400 });
    }
    const { html, url } = await safeFetch(body.url);
    const dom = new JSDOM(html, { url });
    const parsed = new Readability(dom.window.document).parse();
    dom.window.close();
    if (!parsed?.content?.trim()) {
      return NextResponse.json({ error: "No readable article was found on this page." }, { status: 422 });
    }
    const content = sanitizeHtml(parsed.content, {
      allowedTags: sanitizeHtml.defaults.allowedTags.concat(["img", "h1", "h2", "figure", "figcaption", "picture", "source"]),
      allowedAttributes: {
        a: ["href", "name", "target", "rel"],
        img: ["src", "alt", "title", "width", "height", "loading"],
        "*": ["class"]
      },
      allowedSchemes: ["http", "https", "mailto"],
      transformTags: { a: sanitizeHtml.simpleTransform("a", { target: "_blank", rel: "noopener noreferrer" }) }
    });
    return NextResponse.json({
      title: parsed.title || "Clean Reader",
      byline: parsed.byline || null,
      excerpt: parsed.excerpt || null,
      content,
      textContent: parsed.textContent || ""
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to create reader view.";
    return NextResponse.json({ error: message }, { status: 422 });
  }
}
