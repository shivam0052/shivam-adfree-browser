import { NextResponse } from "next/server";
import Parser from "rss-parser";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const parser = new Parser({ timeout: 8000, headers: { "User-Agent": "ClearBrowse/1.0 RSS reader" } });
const FEEDS = [
  { name: "BBC World", url: "https://feeds.bbci.co.uk/news/world/rss.xml" },
  { name: "The Guardian", url: "https://www.theguardian.com/world/rss" },
  { name: "NPR News", url: "https://feeds.npr.org/1001/rss.xml" }
];

export async function GET() {
  const results = await Promise.allSettled(FEEDS.map(async feed => {
    const parsed = await parser.parseURL(feed.url);
    return (parsed.items || []).map(item => ({
      title: String(item.title || "Untitled story").trim(),
      link: typeof item.link === "string" ? item.link : "",
      source: feed.name,
      date: item.isoDate || item.pubDate || ""
    })).filter(item => item.title && /^https?:\/\//i.test(item.link));
  }));
  const items = results.flatMap(result => result.status === "fulfilled" ? result.value : []);
  const unique = [...new Map(items.map(item => [item.link, item])).values()]
    .sort((a, b) => (Date.parse(b.date) || 0) - (Date.parse(a.date) || 0))
    .slice(0, 15);
  return NextResponse.json({ items, updatedAt: new Date().toISOString() }, {
    headers: { "Cache-Control": "no-store" }
  });
}
